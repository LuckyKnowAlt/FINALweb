import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';

function Footer() {
  return (
    <footer className="footer bg-primary text-white text-center py-3">
      <Container>
        <Row>
          <Col>
            <p>&copy; 2024 EduSite. All rights reserved.</p>
            <p>
              Contact: <a href="mailto:your-email@example.com" className="text-white">your-email@example.com</a>
              <a href="https://github.com/your-username" target="_blank" rel="noopener noreferrer" className="text-white ml-3"><i className="fab fa-github"></i></a>
              <a href="https://www.linkedin.com/in/your-linkedin" target="_blank" rel="noopener noreferrer" className="text-white ml-3"><i className="fab fa-linkedin"></i></a>
            </p>
          </Col>
        </Row>
      </Container>
    </footer>
  );
}

export default Footer;
