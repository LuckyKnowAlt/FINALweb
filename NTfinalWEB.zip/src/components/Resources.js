import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Form, InputGroup } from 'react-bootstrap';
import './Resources.css';

// Importing resource logos
import khanAcademyLogo from '../assets/images/khan-academy-logo.png';
import courseraLogo from '../assets/images/coursera-logo.png';
import edxLogo from '../assets/images/edx-logo.png';
import googleScholarLogo from '../assets/images/google-scholar-logo.png';

function Resources({ content }) {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value.toLowerCase());
  };

  const resources = [
    {
      title: 'Khan Academy',
      description: 'A personalized learning resource for all ages.',
      category: 'General',
      url: 'https://www.khanacademy.org/',
      rating: 5,
      logo: khanAcademyLogo,
    },
    {
      title: 'Coursera',
      description: 'Access online courses from top universities.',
      category: 'Courses',
      url: 'https://www.coursera.org/',
      rating: 4,
      logo: courseraLogo,
    },
    {
      title: 'edX',
      description: 'Free online courses from the best universities.',
      category: 'Courses',
      url: 'https://www.edx.org/',
      rating: 4,
      logo: edxLogo,
    },
    {
      title: 'Google Scholar',
      description: 'A freely accessible web search engine that indexes the full text of scholarly literature.',
      category: 'Research',
      url: 'https://scholar.google.com/',
      rating: 5,
      logo: googleScholarLogo,
    },
    // Add more resources as needed
  ];

  const filteredResources = resources.filter((resource) =>
    resource.title.toLowerCase().includes(searchTerm) || resource.category.toLowerCase().includes(searchTerm)
  );

  return (
    <>
      <Container fluid className="resources-header text-center text-white py-5">
        <h1 className="display-4">{content.resourcesTitle}</h1>
      </Container>
      <Container className="my-5">
        <h2 className="text-center">Search Resources</h2>
        <InputGroup className="mb-3">
          <Form.Control
            type="text"
            placeholder="Search for resources..."
            value={searchTerm}
            onChange={handleSearchChange}
          />
        </InputGroup>
        <h2 className="text-center">Top Rated Resources</h2>
        <Row>
          {filteredResources.map((resource, index) => (
            <Col md={4} key={index}>
              <Card className="mb-4 resource-card">
                <Card.Img variant="top" src={resource.logo} alt={resource.title} className="resource-logo" />
                <Card.Body>
                  <Card.Title>{resource.title}</Card.Title>
                  <Card.Text>{resource.description}</Card.Text>
                  <div className="rating">
                    {'★'.repeat(resource.rating) + '☆'.repeat(5 - resource.rating)}
                  </div>
                  <Button variant="primary" href={resource.url} target="_blank" rel="noopener noreferrer">
                    Visit Resource
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
      <Container className="my-5">
        <h2 className="text-center">Resource Categories</h2>
        <Row>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>General</Card.Title>
                <Card.Text>
                  Resources for general education and learning.
                </Card.Text>
                <Button variant="secondary" href="#general">
                  View Resources
                </Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Courses</Card.Title>
                <Card.Text>
                  Online courses and learning platforms.
                </Card.Text>
                <Button variant="secondary" href="#courses">
                  View Resources
                </Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Research</Card.Title>
                <Card.Text>
                  Research tools and scholarly articles.
                </Card.Text>
                <Button variant="secondary" href="#research">
                  View Resources
                </Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default Resources;
