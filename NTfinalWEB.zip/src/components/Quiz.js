import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Form, Button, ProgressBar, Card } from 'react-bootstrap';
import './Quiz.css';

function Quiz({ content }) {
  const [score, setScore] = useState(null);
  const [answers, setAnswers] = useState({
    q1: '',
    q2: '',
    q3: ''
  });
  const [progress, setProgress] = useState(0);
  const [timer, setTimer] = useState(60); // 60 seconds timer

  useEffect(() => {
    const countdown = setInterval(() => {
      setTimer((prevTimer) => (prevTimer > 0 ? prevTimer - 1 : 0));
    }, 1000);

    return () => clearInterval(countdown);
  }, []);

  useEffect(() => {
    const answeredQuestions = Object.values(answers).filter((answer) => answer !== '').length;
    setProgress((answeredQuestions / 3) * 100);
  }, [answers]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAnswers((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let newScore = 0;
    if (answers.q1 === 'correct') newScore++;
    if (answers.q2 === 'correct') newScore++;
    if (answers.q3 === 'correct') newScore++;
    setScore(newScore);
  };

  return (
    <>
      <Container fluid className="quiz-header text-center text-white py-5">
        <h1 className="display-4">{content.quizTitle}</h1>
        <p className="lead">{content.quizDescription}</p>
        <div className="timer">
          <h5>Time Remaining: {timer}s</h5>
        </div>
      </Container>
      <Container className="my-5">
        <Card className="quiz-card">
          <Card.Body>
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col md={4}>
                  <Form.Group controlId="q1" className="mb-4">
                    <Form.Label>{content.question1}</Form.Label>
                    <Form.Check
                      type="radio"
                      label="Correct answer"
                      name="q1"
                      value="correct"
                      onChange={handleChange}
                    />
                    <Form.Check
                      type="radio"
                      label="Incorrect answer"
                      name="q1"
                      value="incorrect"
                      onChange={handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group controlId="q2" className="mb-4">
                    <Form.Label>{content.question2}</Form.Label>
                    <Form.Check
                      type="radio"
                      label="Correct answer"
                      name="q2"
                      value="correct"
                      onChange={handleChange}
                    />
                    <Form.Check
                      type="radio"
                      label="Incorrect answer"
                      name="q2"
                      value="incorrect"
                      onChange={handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group controlId="q3" className="mb-4">
                    <Form.Label>{content.question3}</Form.Label>
                    <Form.Check
                      type="radio"
                      label="Correct answer"
                      name="q3"
                      value="correct"
                      onChange={handleChange}
                    />
                    <Form.Check
                      type="radio"
                      label="Incorrect answer"
                      name="q3"
                      value="incorrect"
                      onChange={handleChange}
                    />
                  </Form.Group>
                </Col>
              </Row>
              <Row>
                <Col md={12} className="text-center">
                  <Button type="submit" variant="primary" disabled={timer === 0}>
                    {content.submit}
                  </Button>
                </Col>
              </Row>
              <Row className="mt-4">
                <Col md={12}>
                  <ProgressBar now={progress} label={`${progress}%`} />
                </Col>
              </Row>
            </Form>
            {score !== null && (
              <Row className="mt-4">
                <Col md={12} className="text-center">
                  <h3>{content.yourScore}: {score}/3</h3>
                </Col>
              </Row>
            )}
          </Card.Body>
        </Card>
      </Container>
    </>
  );
}

export default Quiz;
