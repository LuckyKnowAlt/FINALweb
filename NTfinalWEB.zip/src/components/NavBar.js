import React from 'react';
import { Navbar, Nav, NavDropdown, Container } from 'react-bootstrap';
import { LinkContainer } from 'react-router-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

function NavBar({ switchLanguage }) {
  return (
    <Navbar bg="primary" variant="dark" expand="lg" className="py-3">
      <Container>
        <LinkContainer to="/">
          <Navbar.Brand>EduSite</Navbar.Brand>
        </LinkContainer>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ml-auto">
            <LinkContainer to="/">
              <Nav.Link>Home</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/online-learning">
              <Nav.Link>Online Learning</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/study-tips">
              <Nav.Link>Study Tips</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/resources">
              <Nav.Link>Resources</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/career">
              <Nav.Link>Career</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/quiz">
              <Nav.Link>Quiz</Nav.Link>
            </LinkContainer>
            <NavDropdown title="Language" id="basic-nav-dropdown">
              <NavDropdown.Item onClick={() => switchLanguage('en')}>English</NavDropdown.Item>
              <NavDropdown.Item onClick={() => switchLanguage('ru')}>Русский</NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavBar;
