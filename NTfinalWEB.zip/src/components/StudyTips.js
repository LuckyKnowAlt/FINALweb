import React from 'react';
import { Container, Row, Col, Card, Button, Accordion, Form } from 'react-bootstrap';
import './StudyTips.css';

function StudyTips({ content }) {
  return (
    <>
      <Container fluid className="study-tips-header text-center text-white py-5">
        <h1 className="display-4">{content.studyTips}</h1>
      </Container>
      <Container className="my-5">
        <h2 className="text-center">Effective Study Tips</h2>
        <Accordion>
          <Accordion.Item eventKey="0">
            <Accordion.Header>1. Create a Study Schedule</Accordion.Header>
            <Accordion.Body>
              Plan your study time and stick to a schedule to ensure you cover all the necessary material.
            </Accordion.Body>
          </Accordion.Item>
          <Accordion.Item eventKey="1">
            <Accordion.Header>2. Find a Quiet Study Space</Accordion.Header>
            <Accordion.Body>
              Choose a location free from distractions where you can focus on your studies.
            </Accordion.Body>
          </Accordion.Item>
          <Accordion.Item eventKey="2">
            <Accordion.Header>3. Take Regular Breaks</Accordion.Header>
            <Accordion.Body>
              Take short breaks during your study sessions to rest and recharge.
            </Accordion.Body>
          </Accordion.Item>
          <Accordion.Item eventKey="3">
            <Accordion.Header>4. Use Active Recall</Accordion.Header>
            <Accordion.Body>
              Test yourself on the material you've studied to enhance retention.
            </Accordion.Body>
          </Accordion.Item>
          <Accordion.Item eventKey="4">
            <Accordion.Header>5. Teach What You've Learned</Accordion.Header>
            <Accordion.Body>
              Explain the material to someone else to solidify your understanding.
            </Accordion.Body>
          </Accordion.Item>
          <Accordion.Item eventKey="5">
            <Accordion.Header>6. Use Varied Study Materials</Accordion.Header>
            <Accordion.Body>
              Incorporate different types of study resources, such as videos, textbooks, and quizzes.
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      </Container>
      <Container className="my-5">
        <h2 className="text-center">Downloadable Resources</h2>
        <Row>
          <Col md={6}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Study Planner</Card.Title>
                <Card.Text>
                  Download our customizable study planner to help organize your study sessions.
                </Card.Text>
                <Button href="study-planner.pdf" download>Download Planner</Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={6}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Checklist</Card.Title>
                <Card.Text>
                  Keep track of your study tasks with our handy checklist.
                </Card.Text>
                <Button href="study-checklist.pdf" download>Download Checklist</Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      <Container className="my-5">
        <h2 className="text-center">Test Your Study Habits</h2>
        <Row>
          <Col md={12}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Mini Quiz</Card.Title>
                <Form>
                  <Form.Group controlId="studyHabit1">
                    <Form.Label>Do you create a study schedule?</Form.Label>
                    <Form.Check type="radio" label="Yes" name="habit1" />
                    <Form.Check type="radio" label="No" name="habit1" />
                  </Form.Group>
                  <Form.Group controlId="studyHabit2" className="mt-3">
                    <Form.Label>Do you take regular breaks?</Form.Label>
                    <Form.Check type="radio" label="Yes" name="habit2" />
                    <Form.Check type="radio" label="No" name="habit2" />
                  </Form.Group>
                  <Form.Group controlId="studyHabit3" className="mt-3">
                    <Form.Label>Do you use active recall?</Form.Label>
                    <Form.Check type="radio" label="Yes" name="habit3" />
                    <Form.Check type="radio" label="No" name="habit3" />
                  </Form.Group>
                  <Button variant="primary" type="submit" className="mt-3">
                    Submit
                  </Button>
                </Form>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      <Container className="my-5">
        <h2 className="text-center">Study Music Playlist</h2>
        <Row>
          <Col md={12}>
            <div className="embed-responsive embed-responsive-16by9">
              <iframe
                className="embed-responsive-item"
                src="https://www.youtube.com/embed/PLAYLIST_ID"
                allowFullScreen
                title="Study Music Playlist"
              ></iframe>
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default StudyTips;
