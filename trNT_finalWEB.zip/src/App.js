import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import NavBar from './components/NavBar';
import Home from './components/Home';
import OnlineLearning from './components/OnlineLearning';
import StudyTips from './components/StudyTips';
import Resources from './components/Resources';
import Career from './components/Career';
import Quiz from './components/Quiz';
import Footer from './components/Footer';
import LanguageSwitcher from './components/LanguageSwitcher';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import './components/Home.css';
import './components/OnlineLearning.css';
import './components/StudyTips.css';
import './components/Resources.css';
import './components/Career.css';
import './components/Quiz.css';

const content = {
  en: {
    welcome: "Welcome to EduSite",
    description: "Your go-to resource for all things education.",
    onlineLearning: "Online Learning",
    studyTips: "Study Tips",
    resources: "Resources",
    career: "Career",
    quiz: "Quiz",
    learnMore: "Learn More",
    platform1Title: "Platform 1",
    platform1Desc: "Description of Platform 1",
    platform2Title: "Platform 2",
    platform2Desc: "Description of Platform 2",
    platform3Title: "Platform 3",
    platform3Desc: "Description of Platform 3",
    tipsTitle: "Effective Study Tips",
    tipsDescription: "Discover effective study techniques and time management tips.",
    tip1: "Create a study schedule.",
    tip2: "Find a quiet study space.",
    tip3: "Take regular breaks.",
    resourcesTitle: "Educational Resources",
    resourcesDescription: "Find valuable educational resources and tools.",
    resource1Title: "Khan Academy",
    resource1Description: "A personalized learning resource for all ages.",
    resource2Title: "Coursera",
    resource2Description: "Access online courses from top universities.",
    resource3Title: "TedX",
    resource3Description: "Free online courses from the best universities.",
    careerTitle: "Career Guidance",
    careerDescription: "Career planning advice and job search tips.",
    career1Title: "Identify Your Interests",
    career1Description: "Discover what you are passionate about.",
    career2Title: "Research Career Options",
    career2Description: "Explore different career paths and industries.",
    career3Title: "Prepare Your Resume",
    career3Description: "Learn how to create a strong resume and cover letter.",
    quizTitle: "Test Your Knowledge",
    quizDescription: "Take this quiz to test your knowledge about our site.",
    question1: "What is the primary focus of our website?",
    question2: "Which platform offers free courses?",
    question3: "What is one effective study tip?",
    question4: "Which resource provides access to scholarly articles?",
    question5: "How many study tips are listed on our site?",
    submit: "Submit",
    yourScore: "Your Score",
  },
  ru: {
    welcome: "Добро пожаловать на EduSite",
    description: "Ваш главный ресурс для всего, что касается образования.",
    onlineLearning: "Онлайн обучение",
    studyTips: "Советы по учебе",
    resources: "Ресурсы",
    career: "Карьера",
    quiz: "Викторина",
    learnMore: "Узнать больше",
    platform1Title: "Платформа 1",
    platform1Desc: "Описание Платформы 1",
    platform2Title: "Платформа 2",
    platform2Desc: "Описание Платформы 2",
    platform3Title: "Платформа 3",
    platform3Desc: "Описание Платформы 3",
    tipsTitle: "Эффективные советы по учебе",
    tipsDescription: "Узнайте о эффективных методах учебы и управления временем.",
    tip1: "Создайте расписание занятий.",
    tip2: "Найдите тихое место для учебы.",
    tip3: "Делайте регулярные перерывы.",
    resourcesTitle: "Образовательные ресурсы",
    resourcesDescription: "Найдите ценные образовательные ресурсы и инструменты.",
    resource1Title: "Khan Academy",
    resource1Description: "Персонализированный ресурс для обучения для всех возрастов.",
    resource2Title: "Coursera",
    resource2Description: "Доступ к онлайн-курсам от ведущих университетов.",
    resource3Title: "TedX",
    resource3Description: "Бесплатные онлайн-курсы от лучших университетов.",
    careerTitle: "Карьера",
    careerDescription: "Советы по планированию карьеры и поиску работы.",
    career1Title: "Определите свои интересы",
    career1Description: "Узнайте, чем вы увлечены.",
    career2Title: "Исследуйте варианты карьеры",
    career2Description: "Изучите различные карьерные пути и отрасли.",
    career3Title: "Подготовьте резюме",
    career3Description: "Научитесь создавать сильное резюме и сопроводительное письмо.",
    quizTitle: "Проверьте свои знания",
    quizDescription: "Пройдите этот тест, чтобы проверить свои знания о нашем сайте.",
    question1: "Какова основная цель нашего сайта?",
    question2: "Какая платформа предлагает бесплатные курсы?",
    question3: "Какой один из эффективных советов по учебе?",
    question4: "Какой ресурс предоставляет доступ к научным статьям?",
    question5: "Сколько советов по учебе перечислено на нашем сайте?",
    submit: "Отправить",
    yourScore: "Ваш результат",
  }
};

function App() {
  const [language, setLanguage] = useState('en');

  const switchLanguage = (lang) => {
    setLanguage(lang);
  };

  return (
    <div className="App">
      <Router>
        <NavBar switchLanguage={switchLanguage} />
        <LanguageSwitcher switchLanguage={switchLanguage} />
        <Routes>
          <Route path="/" element={<Home content={content[language]} />} />
          <Route path="/online-learning" element={<OnlineLearning content={content[language]} />} />
          <Route path="/study-tips" element={<StudyTips content={content[language]} />} />
          <Route path="/resources" element={<Resources content={content[language]} />} />
          <Route path="/career" element={<Career content={content[language]} />} />
          <Route path="/quiz" element={<Quiz content={content[language]} />} />
        </Routes>
        <Footer />
      </Router>
    </div>
  );
}

export default App;
