import React from 'react';
import { Container, Row, Col, Card, Button, Accordion } from 'react-bootstrap';
import './OnlineLearning.css';

// Importing images
import course1Img from '../assets/images/course-1.jpg';
import course2Img from '../assets/images/course-2.jpg';
import course3Img from '../assets/images/course-3.jpg';

function OnlineLearning({ content }) {
  return (
    <>
      <Container fluid className="online-learning-header text-center text-white py-5">
        <h1 className="display-4">{content.onlineLearning}</h1>
      </Container>
      <Container className="my-5">
        <Row>
          <Col md={6}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Introductory Video</Card.Title>
                <div className="embed-responsive embed-responsive-16by9">
                  <iframe
                    className="embed-responsive-item"
                    src="https://www.youtube.com/embed/LOS5WB75gkY"
                    allowFullScreen
                    title="Introductory Video"
                  ></iframe>
                </div>
              </Card.Body>
            </Card>
          </Col>
          <Col md={6}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Course Platform Overview</Card.Title>
                <div className="embed-responsive embed-responsive-16by9">
                  <iframe
                    className="embed-responsive-item"
                    src="https://www.youtube.com/embed/I2UBjN5ER4s"
                    allowFullScreen
                    title="Course Platform Overview"
                  ></iframe>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      <Container className="my-5">
        <h2 className="text-center">Top Courses</h2>
        <Row>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src={course1Img} alt="Course 1" />
              <Card.Body>
                <Card.Title>{content.platform1Title}</Card.Title>
                <Card.Text>{content.platform1Desc}</Card.Text>
                <div className="rating">
                  <span>★★★★★</span>
                </div>
                <Button variant="primary" href="#platform-1">Learn More</Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src={course2Img} alt="Course 2" />
              <Card.Body>
                <Card.Title>{content.platform2Title}</Card.Title>
                <Card.Text>{content.platform2Desc}</Card.Text>
                <div className="rating">
                  <span>★★★★☆</span>
                </div>
                <Button variant="primary" href="#platform-2">Learn More</Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src={course3Img} alt="Course 3" />
              <Card.Body>
                <Card.Title>{content.platform3Title}</Card.Title>
                <Card.Text>{content.platform3Desc}</Card.Text>
                <div className="rating">
                  <span>★★★★★</span>
                </div>
                <Button variant="primary" href="#platform-3">Learn More</Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      <Container className="my-5">
        <h2 className="text-center">Frequently Asked Questions</h2>
        <Accordion>
          <Accordion.Item eventKey="0">
            <Accordion.Header>What is online learning?</Accordion.Header>
            <Accordion.Body>
              Online learning is a form of education where students use the internet to access course materials, interact with instructors, and complete assignments.
            </Accordion.Body>
          </Accordion.Item>
          <Accordion.Item eventKey="1">
            <Accordion.Header>How do I enroll in a course?</Accordion.Header>
            <Accordion.Body>
              To enroll in a course, browse our course catalog, select the course you're interested in, and follow the enrollment instructions.
            </Accordion.Body>
          </Accordion.Item>
          <Accordion.Item eventKey="2">
            <Accordion.Header>Are there any prerequisites?</Accordion.Header>
            <Accordion.Body>
              Some courses may have prerequisites. Please check the course description for specific requirements.
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      </Container>
    </>
  );
}

export default OnlineLearning;
