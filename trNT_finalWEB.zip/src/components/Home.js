import React, { useEffect } from 'react';
import { Container, Row, Col, Card, Button, Carousel, Form } from 'react-bootstrap';
import './Home.css';

// Importing images
import onlineLearningImg from '../assets/images/online-learning.jpg';
import studyTipsImg from '../assets/images/study-tips.jpg';
import resourcesImg from '../assets/images/resources.jpg';

function Home({ content }) {
  useEffect(() => {
    document.addEventListener('click', handleClick);
    document.addEventListener('mouseover', handleMouseOver);
    document.addEventListener('keypress', handleKeyPress);

    return () => {
      document.removeEventListener('click', handleClick);
      document.removeEventListener('mouseover', handleMouseOver);
      document.removeEventListener('keypress', handleKeyPress);
    };
  }, []);

  const handleClick = () => {
    console.log('Element clicked!');
  };

  const handleMouseOver = () => {
    console.log('Element hovered!');
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      console.log('Enter key pressed!');
    }
  };

  const playSound = () => {
    const audio = document.getElementById('buttonClickSound');
    audio.play();
  };

  return (
    <>
      <audio id="buttonClickSound" src="/assets/audio/button-click.mp3" />
      <Container fluid className="home-header text-center text-white py-5">
        <h1 className="display-4 fade-in">{content.welcome}</h1>
        <p className="lead fade-in">{content.description}</p>
      </Container>
      <Container className="my-5">
        <Carousel>
          <Carousel.Item className="animate__animated animate__fadeIn">
            <img className="d-block w-100" src={onlineLearningImg} alt="First slide" />
            <Carousel.Caption className="carousel-caption-bg">
              <h3>{content.onlineLearning}</h3>
              <p>{content.onlineLearning}</p>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item className="animate__animated animate__fadeIn">
            <img className="d-block w-100" src={studyTipsImg} alt="Second slide" />
            <Carousel.Caption className="carousel-caption-bg">
              <h3>{content.studyTips}</h3>
              <p>{content.studyTips}</p>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item className="animate__animated animate__fadeIn">
            <img className="d-block w-100" src={resourcesImg} alt="Third slide" />
            <Carousel.Caption className="carousel-caption-bg">
              <h3>{content.resources}</h3>
              <p>{content.resources}</p>
            </Carousel.Caption>
          </Carousel.Item>
        </Carousel>
      </Container>
      <Container className="my-5">
        <Row>
          <Col md={4}>
            <Card className="mb-4 card-hover animate__animated animate__zoomIn">
              <Card.Body>
                <Card.Title>Students Enrolled</Card.Title>
                <h2 className="animated-statistic">2000+</h2>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4 card-hover animate__animated animate__zoomIn">
              <Card.Body>
                <Card.Title>Courses Available</Card.Title>
                <h2 className="animated-statistic">150+</h2>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4 card-hover animate__animated animate__zoomIn">
              <Card.Body>
                <Card.Title>Countries Represented</Card.Title>
                <h2 className="animated-statistic">50+</h2>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      <Container className="my-5">
        <h2 className="text-center">What Our Users Say</h2>
        <Row>
          <Col md={4}>
            <Card className="mb-4 card-hover animate__animated animate__fadeInUp">
              <Card.Body>
                <Card.Text>"This platform has transformed my learning experience!"</Card.Text>
                <Card.Footer>- Jane Doe</Card.Footer>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4 card-hover animate__animated animate__fadeInUp">
              <Card.Body>
                <Card.Text>"Highly recommend to anyone looking to improve their skills."</Card.Text>
                <Card.Footer>- John Smith</Card.Footer>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4 card-hover animate__animated animate__fadeInUp">
              <Card.Body>
                <Card.Text>"Excellent resources and supportive community."</Card.Text>
                <Card.Footer>- Emily Johnson</Card.Footer>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      <Container className="my-5">
        <h2 className="text-center">Subscribe to Our Newsletter</h2>
        <Form className="animate__animated animate__fadeIn">
          <Row>
            <Col md={8} className="offset-md-2">
              <Form.Group controlId="newsletterEmail">
                <Form.Control type="email" placeholder="Enter your email" />
              </Form.Group>
              <Button variant="primary" type="submit" className="mt-3 w-100" onClick={playSound}>
                <i className="fas fa-paper-plane"></i> Subscribe
              </Button>
            </Col>
          </Row>
        </Form>
      </Container>
    </>
  );
}

export default Home;
