import React from 'react';
import { Container, Row, Col, Card, Button, Accordion } from 'react-bootstrap';
import './Career.css';

function Career({ content }) {
  return (
    <>
      <Container fluid className="career-header text-center text-white py-5">
        <h1 className="display-4">{content.careerTitle}</h1>
        <p className="lead">{content.careerDescription}</p>
      </Container>
      <Container className="my-5">
        <h2 className="text-center mb-4">Career Paths</h2>
        <Accordion>
          <Accordion.Item eventKey="0">
            <Accordion.Header>Identify Your Interests</Accordion.Header>
            <Accordion.Body>
              Discover what you are passionate about and how it can translate into a career. Explore different activities and subjects that interest you.
              <Button variant="primary" href="#interests" className="mt-3">Learn More</Button>
            </Accordion.Body>
          </Accordion.Item>
          <Accordion.Item eventKey="1">
            <Accordion.Header>Research Career Options</Accordion.Header>
            <Accordion.Body>
              Explore various career paths and industries. Learn about the job market, required skills, and potential growth.
              <Button variant="primary" href="#career-options" className="mt-3">Learn More</Button>
            </Accordion.Body>
          </Accordion.Item>
          <Accordion.Item eventKey="2">
            <Accordion.Header>Prepare Your Resume</Accordion.Header>
            <Accordion.Body>
              Learn how to create a strong resume and cover letter. Find tips on how to present your skills and experiences effectively.
              <Button variant="primary" href="#resume" className="mt-3">Learn More</Button>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      </Container>
      <Container className="my-5">
        <h2 className="text-center mb-4">Career Resources and Tips</h2>
        <Row>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Networking Tips</Card.Title>
                <Card.Text>Learn how to build a professional network and connect with industry professionals.</Card.Text>
                <Button href="networking-tips.pdf" download>Download Guide</Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Interview Preparation</Card.Title>
                <Card.Text>Get tips on how to prepare for job interviews and make a great impression.</Card.Text>
                <Button href="interview-preparation.pdf" download>Download Guide</Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Job Search Strategies</Card.Title>
                <Card.Text>Explore effective strategies for finding job opportunities in your field.</Card.Text>
                <Button href="job-search-strategies.pdf" download>Download Guide</Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      <Container className="my-5">
        <h2 className="text-center mb-4">Career Planning Videos</h2>
        <Row>
          <Col md={12}>
            <div className="embed-responsive embed-responsive-16by9">
              <iframe
                className="embed-responsive-item"
                src="https://www.youtube.com/embed/jVssNpBk37k"
                allowFullScreen
                title="Career Planning Video"
              ></iframe>
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default Career;
