import React from 'react';

function LanguageSwitcher({ switchLanguage }) {
  return (
    <div className="language-switcher">
      <button onClick={() => switchLanguage('en')}>EN</button>
      <button onClick={() => switchLanguage('ru')}>РУ</button>
    </div>
  );
}

export default LanguageSwitcher;
