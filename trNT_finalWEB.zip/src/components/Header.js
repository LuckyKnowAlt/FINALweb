import React from 'react';
import { Container } from 'react-bootstrap';
import './Header.css';

function Header({ title, description }) {
  return (
    <Container fluid className="header text-center text-white py-5">
      <h1 className="fade-in">{title}</h1>
      <p className="fade-in">{description}</p>
    </Container>
  );
}

export default Header;
